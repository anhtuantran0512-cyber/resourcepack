#version 150

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    // Bắt mã màu đỏ mặc định của Mojang (#EF323D / RGB: 239, 50, 61)
    if (abs(vertexColor.r - 239.0/255.0) < 0.02 && 
        abs(vertexColor.g - 50.0/255.0) < 0.02 && 
        abs(vertexColor.b - 61.0/255.0) < 0.02) {
        // Đổi màu nền sang tông đen mờ tiệp màu với hình ảnh (RGB: 10, 10, 10)
        fragColor = vec4(10.0/255.0, 10.0/255.0, 10.0/255.0, vertexColor.a);
    } else {
        fragColor = vertexColor;
    }
}
